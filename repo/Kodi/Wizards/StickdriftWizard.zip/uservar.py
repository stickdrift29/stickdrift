'''#####-----Build File-----#####'''
buildfile = 'https://stickdrift29.github.io/stickdrift/repo/Kodi/Wizards/builds.xml'

